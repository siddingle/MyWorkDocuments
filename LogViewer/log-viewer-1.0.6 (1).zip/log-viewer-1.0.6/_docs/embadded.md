LogViewer can be added to existing java web application as a library. The library contains the log-viewer servlet.
You can map the servlet to any URL and it will show logs. Log configuration will be detected automatically.

###### TO DO: write documentation
