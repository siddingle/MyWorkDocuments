package com.logviewer.utils;

public interface TestListener {

    void beforeTest();

}
