package com.logviewer.api;

import com.typesafe.config.Config;

public interface LvUiConfigurer {
    Config getUiConfig();
}
