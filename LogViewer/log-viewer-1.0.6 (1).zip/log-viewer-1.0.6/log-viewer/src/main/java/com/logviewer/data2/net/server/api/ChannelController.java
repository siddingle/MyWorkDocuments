package com.logviewer.data2.net.server.api;

public interface ChannelController {

    void close();

}
