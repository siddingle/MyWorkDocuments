package com.logviewer.web.session;

public interface LogObserver {

}
