package com.logviewer.data2.net.server;

import java.io.Serializable;

public interface Message extends Serializable {

}
