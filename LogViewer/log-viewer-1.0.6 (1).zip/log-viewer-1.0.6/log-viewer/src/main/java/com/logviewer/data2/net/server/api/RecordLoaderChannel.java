package com.logviewer.data2.net.server.api;

public interface RecordLoaderChannel {

    void setTimeLimit(long timeLimit);

}
