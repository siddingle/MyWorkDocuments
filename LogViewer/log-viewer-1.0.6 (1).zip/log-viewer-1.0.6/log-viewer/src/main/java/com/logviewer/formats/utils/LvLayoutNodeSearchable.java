package com.logviewer.formats.utils;

public interface LvLayoutNodeSearchable {

    int search(String s, int offset, int end);

}
