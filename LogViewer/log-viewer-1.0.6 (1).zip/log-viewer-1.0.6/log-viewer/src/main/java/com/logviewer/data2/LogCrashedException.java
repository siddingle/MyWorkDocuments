package com.logviewer.data2;

public class LogCrashedException extends Exception {

}
