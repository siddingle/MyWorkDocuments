package com.logviewer.generator;

public class ViewConfig {


}
