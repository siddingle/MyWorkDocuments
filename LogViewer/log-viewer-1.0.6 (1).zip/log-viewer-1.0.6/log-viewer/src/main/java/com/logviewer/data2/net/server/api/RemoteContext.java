package com.logviewer.data2.net.server.api;

import com.logviewer.data2.LogService;

public interface RemoteContext {

    LogService getLogService();

}
