package com.logviewer.formats.utils;

public interface LvLayoutNodeParser {



}
