export interface SlElement extends HTMLElement {
    virtual: boolean;
    strLen: number;
    highlightNode: boolean;
}
