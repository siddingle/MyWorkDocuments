export interface SlStyle {
    color?: string;
    fontWeight?: string;
    fontStyle?: string;

    className?: string;
}
