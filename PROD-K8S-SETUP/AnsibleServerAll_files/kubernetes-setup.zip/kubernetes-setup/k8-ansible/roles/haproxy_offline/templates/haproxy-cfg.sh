cat <<EOF >/etc/haproxy/haproxy.cfg
frontend kubernetes-frontend
  bind *:6443
  mode tcp
  option tcplog
  default_backend kubernetes-backend

backend kubernetes-backend
  option httpchk GET /healthz
  http-check expect status 200
  mode tcp
  option ssl-hello-chk
  balance roundrobin
    server master1 192.168.70.6:6443 check fall 3 rise 2
    server master2 192.168.70.7:6443 check fall 3 rise 2
    server master3 192.168.70.8:6443 check fall 3 rise 2
EOF
