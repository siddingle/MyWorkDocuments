# kubernetes-setup
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/hq9iaROZr8s/0.jpg)](https://www.youtube.com/watch?v=hq9iaROZr8s)
